//import Component
//Component class used to convert the TypeScript Standards to Equalent HTML Standards
import { Component } from "@angular/core";

//import dbService
import { dbService } from "../services/db.service";

//use Component
@Component({
    selector:"mongodb",
    templateUrl:"./mongodb.component.html"
})
//export the class
export class mongodbComponent{
    //declare variable
    private result:string;
    //create the object to dbService
    //in general we will use constructors to create the objects
    //dependency injection
    constructor(private obj:dbService){}

    //ngOnInit() is the main method in Component
    //ngOnInit() used to write the business logic
    ngOnInit(){
        this.result = this.obj.mongodb();
    }
};