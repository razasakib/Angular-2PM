//import Injectable
//Injectable is the predefined class
//Injectable class used to create the service
import { Injectable } from "@angular/core";
//use Injectable
//we will use predefined classes by using "@"
//using predefined classes with "@" symbol called as decorator
@Injectable({
    providedIn:"root"
})
//where "providedIn" makes the service as global service

//export the class
export class dbService{
    public mysql():string{
        return "MySQL Data Soon...!";
    };
    public mongodb():string{
        return "MongoDB Data Soon...!";
    };
};