import { Calculator } from "./calc";
//"karma with jasmine" starts the execution from "describe()"
describe("calculator testing",()=>{
    //describe()
    //inner describe() used to write the test cases to particular function
    describe("add function testing",()=>{
        //it() function used to write the test suite
        it("10+10 should be equal to 20",()=>{
            let obj:Calculator = new Calculator();
            const result = obj.add(10,10);
            //assertion
            expect(result).toBe(20);
        });
    });
    describe("sub function testing",()=>{
        it("10-10 should be equal to 0",()=>{
            let obj:Calculator = new Calculator();
            const result = obj.sub(10,10);
            expect(result).toBe(0);
        });
    });
    describe("array testing",()=>{
        it("check 30 in my_ary",()=>{
            let obj:Calculator = new Calculator();
            expect(obj.my_ary).toContain(30);
        });
    });
});