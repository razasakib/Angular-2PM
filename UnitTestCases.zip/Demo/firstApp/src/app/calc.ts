export class Calculator{
    public add(num1:number,num2:number):number{
        return num1+num2;
    };

    public sub(num1:number,num2:number):number{
        return num1-num2;
    };

    public my_ary:number[] = [10,20,30,40,50];
};